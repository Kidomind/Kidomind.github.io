KidoMind icon paketi

Bu klasör, yaygın web/PWA ve mobil ikon ölçülerini içerir.
- icon.png / icon-512.png: 512x512
- icon-192.png: 192x192
- icon-maskable-512.png: maskable ikon için güvenli kenar boşluklu 512x512
- favicon-32.png / favicon-16.png: favicon boyutları

Not: GitHub projenizdeki mevcut icon klasörünün dosya adları farklıysa, bu dosyaları doğrudan kopyalamadan önce mevcut yapılandırmadaki adlarla eşleştirin. Android mipmap/adaptive icon kaynakları veya Capacitor yapılandırması ayrıca gerekebilir.
